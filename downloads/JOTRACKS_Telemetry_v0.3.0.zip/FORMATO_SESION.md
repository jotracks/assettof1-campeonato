# Formato JOTRACKS Telemetry Session

Los archivos `*.jotracks.json` usan el identificador:

```json
{
  "format": "jotracks.telemetry.session",
  "formatVersion": 2
}
```

La raíz contiene metadatos de pista, auto, piloto y resolución de muestreo,
además de `sectors`, `trackMap` y el arreglo `laps`.

Cada vuelta incluye:

- `number`, `timeMs`, `valid` y `coverage`.
- `channels.index`: posición discreta dentro de la vuelta.
- `channels.lapTimeMs`: tiempo acumulado.
- `channels.throttle`, `brake` y `clutch`: valores entre 0 y 1.
- `channels.steer`: volante normalizado entre -1 y 1.
- `channels.steerDeg`: volante en grados.
- `channels.speedKmh` y `gear`.
- `channels.fuelLiters` y `fuelUsedLiters`.
- `channels.ersLevel`, `ersDeploy` y `ersRecover`.
- `channels.mgukDelivery` y `mgukRecovery`.
- `channels.x`, `y` y `z`: posición mundial del auto.

Cada vuelta también incluye:

- `tyreCompound` y `tyreCompoundLong`.
- `fuelStartLiters`, `fuelEndLiters` y `fuelUsedLiters`.
- `hybridAvailable`, `ersStartPercent`, `ersEndPercent`,
  `ersDeployedPercent` y `ersRecoveredPercent`.

La raíz incluye `capabilities.fuel`, `capabilities.tyres` y
`capabilities.hybrid` para que el analizador oculte datos no disponibles.

Los canales usan arreglos paralelos: el elemento `N` de cada arreglo describe
la misma muestra indicada por `channels.index[N]`.
