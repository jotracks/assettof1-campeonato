local APP_VERSION = '0.3.0'
local FORMAT_ID = 'jotracks.telemetry.session'
local FORMAT_VERSION = 2
local BIN_COUNT = 1000
local MIN_COMPLETE_COVERAGE = 0.80
local MAX_INTERPOLATION_GAP = 60
local ERS_FLOW_REFERENCE_PER_SECOND = 0.08

local sim = ac.getSim()
local car = ac.getCar(0)

local colors = {
  throttle = rgbm(0.25, 1.00, 0.35, 1.00),
  brake = rgbm(1.00, 0.22, 0.16, 1.00),
  clutch = rgbm(0.15, 0.72, 1.00, 1.00),
  steer = rgbm(1.00, 1.00, 1.00, 1.00),
  fuel = rgbm(1.00, 0.75, 0.28, 1.00),
  energy = rgbm(0.30, 1.00, 0.84, 1.00),
  text = rgbm(1.00, 1.00, 1.00, 0.82),
  grid = rgbm(1.00, 1.00, 1.00, 0.10),
  cursor = rgbm(1.00, 1.00, 1.00, 0.34),
  background = rgbm(0.018, 0.022, 0.028, 1.00)
}

local settings = ac.storage({
  showPrevious = true,
  showClutch = true,
  showSteer = false,
  showHeader = false,
  showGrid = false,
  showProgressCursor = false,
  clutchAsPedal = true,
  autoExport = true,
  lineThickness = 2.0,
  backgroundOpacity = 0.0
})

local exportDirectory = ac.getFolder(ac.FolderID.ACDocuments) .. '/telemetry/JOTRACKS Telemetry'
local sessionStamp = os.date('%Y%m%d_%H%M%S')

local function clamp01(value)
  return math.max(0, math.min(1, tonumber(value) or 0))
end

local function clampSigned(value)
  return math.max(-1, math.min(1, tonumber(value) or 0))
end

local function round(value, decimals)
  local factor = 10 ^ (decimals or 0)
  value = tonumber(value) or 0
  if value >= 0 then
    return math.floor(value * factor + 0.5) / factor
  end
  return math.ceil(value * factor - 0.5) / factor
end

local function safeID(value)
  local result = tostring(value or 'unknown'):gsub('[^%w_%-]+', '_')
  result = result:gsub('^_+', ''):gsub('_+$', '')
  return #result > 0 and result or 'unknown'
end

local trackID = ac.getTrackFullID('_') or ac.getTrackID() or 'track'
local carID = ac.getCarID(0) or 'car'
local sessionFilename = string.format(
  '%s/%s_%s_%s.jotracks.json',
  exportDirectory,
  sessionStamp,
  safeID(trackID),
  safeID(carID)
)

local sessionData = {
  format = FORMAT_ID,
  formatVersion = FORMAT_VERSION,
  appVersion = APP_VERSION,
  createdAt = os.date('%Y-%m-%dT%H:%M:%S'),
  updatedAt = os.date('%Y-%m-%dT%H:%M:%S'),
  sampleCount = BIN_COUNT,
  lapCount = 0,
  bestLapNumber = 0,
  bestLapTimeMs = 0,
  bestLapValid = false,
  driver = ac.getDriverName(0) or '',
  track = {
    id = trackID,
    name = ac.getTrackName() or trackID,
    lengthM = round(sim.trackLengthM, 2)
  },
  car = {
    id = carID,
    name = ac.getCarName(0) or carID,
    steerLockDeg = car and round(car.steerLock, 2) or 0
  },
  capabilities = {
    fuel = false,
    tyres = false,
    hybrid = false
  },
  sectors = {},
  trackMap = {index = {}, x = {}, y = {}, z = {}},
  laps = {}
}

local function newTrace(fullLap)
  return {
    throttle = {}, brake = {}, clutch = {}, steer = {}, steerDeg = {},
    timeMs = {}, speedKmh = {}, gear = {},
    fuelLiters = {}, fuelUsedLiters = {},
    ersLevel = {}, ersDeploy = {}, ersRecover = {},
    mgukDelivery = {}, mgukRecovery = {},
    worldX = {}, worldY = {}, worldZ = {}, sector = {},
    sampleCount = 0,
    fullLap = fullLap == true,
    valid = true,
    lastBin = nil,
    lastSample = nil,
    lastFuelLiters = nil,
    lastERSLevel = nil,
    fuelAvailable = false,
    hybridAvailable = false,
    fuelStartLiters = nil,
    fuelEndLiters = nil,
    fuelConsumedLiters = 0,
    ersStartPercent = nil,
    ersEndPercent = nil,
    ersDeployedPercent = 0,
    ersRecoveredPercent = 0,
    tyreCompound = '',
    tyreCompoundLong = '',
    lapNumber = 0,
    lapTimeMs = 0
  }
end

local currentTrace = newTrace(car and clamp01(car.splinePosition) <= 0.03)
local previousTrace = nil
local lastLapCount = car and car.lapCount or 0
local liveThrottle, liveBrake, liveClutch, liveSteer = 0, 0, 0, 0
local liveGear, liveFuel, liveERSLevel = 0, 0, 0
local liveERSDeploy, liveERSRecover, liveHybridAvailable = 0, 0, false
local liveTyreCompound = ''
local liveSplinePosition = car and clamp01(car.splinePosition) or 0
local lastCSVPath, lastSessionPath = nil, nil
local exportStatus, exportStatusTime = '', 0

local function setTraceSample(trace, index, sample)
  if trace.throttle[index] == nil then trace.sampleCount = trace.sampleCount + 1 end
  trace.throttle[index] = sample.throttle
  trace.brake[index] = sample.brake
  trace.clutch[index] = sample.clutch
  trace.steer[index] = sample.steer
  trace.steerDeg[index] = sample.steerDeg
  trace.timeMs[index] = sample.timeMs
  trace.speedKmh[index] = sample.speedKmh
  trace.gear[index] = sample.gear
  trace.fuelLiters[index] = sample.fuelLiters
  trace.fuelUsedLiters[index] = sample.fuelUsedLiters
  trace.ersLevel[index] = sample.ersLevel
  trace.ersDeploy[index] = math.max(trace.ersDeploy[index] or 0, sample.ersDeploy)
  trace.ersRecover[index] = math.max(trace.ersRecover[index] or 0, sample.ersRecover)
  trace.mgukDelivery[index] = sample.mgukDelivery
  trace.mgukRecovery[index] = sample.mgukRecovery
  trace.worldX[index] = sample.worldX
  trace.worldY[index] = sample.worldY
  trace.worldZ[index] = sample.worldZ
  trace.sector[index] = sample.sector
end

local function interpolateNumber(a, b, mix)
  return a + (b - a) * mix
end

local function interpolateSample(a, b, mix)
  return {
    throttle = interpolateNumber(a.throttle, b.throttle, mix),
    brake = interpolateNumber(a.brake, b.brake, mix),
    clutch = interpolateNumber(a.clutch, b.clutch, mix),
    steer = interpolateNumber(a.steer, b.steer, mix),
    steerDeg = interpolateNumber(a.steerDeg, b.steerDeg, mix),
    timeMs = interpolateNumber(a.timeMs, b.timeMs, mix),
    speedKmh = interpolateNumber(a.speedKmh, b.speedKmh, mix),
    gear = math.floor(interpolateNumber(a.gear, b.gear, mix) + 0.5),
    fuelLiters = interpolateNumber(a.fuelLiters, b.fuelLiters, mix),
    fuelUsedLiters = interpolateNumber(a.fuelUsedLiters, b.fuelUsedLiters, mix),
    ersLevel = interpolateNumber(a.ersLevel, b.ersLevel, mix),
    ersDeploy = interpolateNumber(a.ersDeploy, b.ersDeploy, mix),
    ersRecover = interpolateNumber(a.ersRecover, b.ersRecover, mix),
    mgukDelivery = math.floor(interpolateNumber(a.mgukDelivery, b.mgukDelivery, mix) + 0.5),
    mgukRecovery = math.floor(interpolateNumber(a.mgukRecovery, b.mgukRecovery, mix) + 0.5),
    worldX = interpolateNumber(a.worldX, b.worldX, mix),
    worldY = interpolateNumber(a.worldY, b.worldY, mix),
    worldZ = interpolateNumber(a.worldZ, b.worldZ, mix),
    sector = mix < 0.5 and a.sector or b.sector
  }
end

local function recordSample(trace, splinePosition, dt)
  local index = math.floor(splinePosition * (BIN_COUNT - 1)) + 1
  local clutchRaw = clamp01(car.clutch)
  local steerDeg = tonumber(car.steer) or 0
  local steerLock = math.max(1, tonumber(car.steerLock) or 1)
  local position = car.position
  local sectorName = trace.sector[index]
  if not sectorName or #sectorName == 0 then
    sectorName = ac.getTrackSectorName(splinePosition) or ''
  end

  if #trace.tyreCompound == 0 then
    trace.tyreCompound = ac.getTyresName and tostring(ac.getTyresName(0) or '') or ''
    trace.tyreCompoundLong = ac.getTyresLongName and tostring(ac.getTyresLongName(0) or '') or trace.tyreCompound
  end

  local fuelRaw = tonumber(car.fuel)
  local fuelAvailable = fuelRaw ~= nil
  local fuelLiters = math.max(0, fuelRaw or 0)
  if fuelAvailable then
    trace.fuelAvailable = true
    if trace.fuelStartLiters == nil then trace.fuelStartLiters = fuelLiters end
    if trace.lastFuelLiters and fuelLiters < trace.lastFuelLiters then
      trace.fuelConsumedLiters = trace.fuelConsumedLiters + (trace.lastFuelLiters - fuelLiters)
    end
    trace.lastFuelLiters = fuelLiters
    trace.fuelEndLiters = fuelLiters
  end

  local hybridAvailable = car.kersPresent and true or false
  local ersLevel = hybridAvailable and clamp01(car.kersCharge) or 0
  local ersDeploy, ersRecover = 0, 0
  if hybridAvailable then
    trace.hybridAvailable = true
    if trace.ersStartPercent == nil then trace.ersStartPercent = ersLevel * 100 end
    if trace.lastERSLevel ~= nil then
      local delta = ersLevel - trace.lastERSLevel
      local elapsed = math.max(1 / 240, math.min(0.25, tonumber(dt) or 1 / 60))
      if delta < -0.000001 then
        trace.ersDeployedPercent = trace.ersDeployedPercent - delta * 100
        ersDeploy = clamp01((-delta / elapsed) / ERS_FLOW_REFERENCE_PER_SECOND)
      elseif delta > 0.000001 then
        trace.ersRecoveredPercent = trace.ersRecoveredPercent + delta * 100
        ersRecover = clamp01((delta / elapsed) / ERS_FLOW_REFERENCE_PER_SECOND)
      end
    end
    trace.lastERSLevel = ersLevel
    trace.ersEndPercent = ersLevel * 100
  end

  local sample = {
    throttle = clamp01(car.gas),
    brake = clamp01(car.brake),
    clutch = settings.clutchAsPedal and (1 - clutchRaw) or clutchRaw,
    steer = clampSigned(steerDeg / steerLock),
    steerDeg = steerDeg,
    timeMs = math.max(0, tonumber(car.lapTimeMs) or 0),
    speedKmh = math.max(0, tonumber(car.speedKmh) or 0),
    gear = tonumber(car.gear) or 0,
    fuelLiters = fuelLiters,
    fuelUsedLiters = trace.fuelConsumedLiters,
    ersLevel = ersLevel,
    ersDeploy = ersDeploy,
    ersRecover = ersRecover,
    mgukDelivery = hybridAvailable and (tonumber(car.mgukDelivery) or 0) or 0,
    mgukRecovery = hybridAvailable and (tonumber(car.mgukRecovery) or 0) or 0,
    worldX = position and tonumber(position.x) or 0,
    worldY = position and tonumber(position.y) or 0,
    worldZ = position and tonumber(position.z) or 0,
    sector = sectorName
  }

  liveThrottle, liveBrake, liveClutch, liveSteer = sample.throttle, sample.brake, sample.clutch, sample.steer
  liveGear, liveFuel, liveERSLevel = sample.gear, sample.fuelLiters, sample.ersLevel
  liveERSDeploy, liveERSRecover, liveHybridAvailable = sample.ersDeploy, sample.ersRecover, hybridAvailable
  liveTyreCompound = trace.tyreCompound

  if trace.lastBin and trace.lastSample and index > trace.lastBin then
    local gap = index - trace.lastBin
    if gap <= MAX_INTERPOLATION_GAP then
      for filledIndex = trace.lastBin + 1, index do
        local mix = (filledIndex - trace.lastBin) / gap
        setTraceSample(trace, filledIndex, interpolateSample(trace.lastSample, sample, mix))
      end
    else
      setTraceSample(trace, index, sample)
    end
  else
    setTraceSample(trace, index, sample)
  end

  trace.lastBin, trace.lastSample = index, sample
  trace.valid = trace.valid and car.isLapValid ~= false
end

local function csvText(value)
  return '"' .. tostring(value or ''):gsub('"', '""') .. '"'
end

local function exportTraceCSV(trace, manual)
  if not trace then return false end
  local stamp = os.date('%Y%m%d_%H%M%S')
  local validity = trace.valid and 'valid' or 'invalid'
  local mode = manual and 'manual' or 'auto'
  local filename = string.format('%s/%s_%s_lap_%03d_%s_%s_%s.csv',
    exportDirectory, stamp, safeID(trackID), trace.lapNumber or 0,
    validity, safeID(carID), mode)

  local rows = {
    'track_id,car_id,lap_number,lap_valid,completed_lap_time_ms,tyre_compound,fuel_start_l,fuel_end_l,fuel_used_l,ers_deployed_pct,ers_recovered_pct,sample_index,lap_position,distance_m,sample_lap_time_ms,throttle,brake,clutch,steer,steer_deg,speed_kmh,gear,fuel_l,fuel_used_at_sample_l,ers_level_pct,ers_deploy,ers_recover,mguk_delivery,mguk_recovery,world_x,world_y,world_z,sector'
  }
  local trackLengthM = math.max(0, tonumber(sim.trackLengthM) or 0)

  for index = 1, BIN_COUNT do
    if trace.throttle[index] ~= nil then
      local lapPosition = (index - 1) / (BIN_COUNT - 1)
      rows[#rows + 1] = table.concat({
        csvText(trackID), csvText(carID), tostring(trace.lapNumber or 0),
        trace.valid and '1' or '0', tostring(trace.lapTimeMs or 0),
        csvText(trace.tyreCompound or ''),
        string.format('%.4f', trace.fuelStartLiters or 0),
        string.format('%.4f', trace.fuelEndLiters or 0),
        string.format('%.4f', trace.fuelConsumedLiters or 0),
        string.format('%.4f', trace.ersDeployedPercent or 0),
        string.format('%.4f', trace.ersRecoveredPercent or 0),
        tostring(index - 1), string.format('%.6f', lapPosition),
        string.format('%.3f', lapPosition * trackLengthM),
        string.format('%.0f', trace.timeMs[index] or 0),
        string.format('%.6f', trace.throttle[index] or 0),
        string.format('%.6f', trace.brake[index] or 0),
        string.format('%.6f', trace.clutch[index] or 0),
        string.format('%.6f', trace.steer[index] or 0),
        string.format('%.3f', trace.steerDeg[index] or 0),
        string.format('%.3f', trace.speedKmh[index] or 0),
        tostring(trace.gear[index] or 0),
        string.format('%.4f', trace.fuelLiters[index] or 0),
        string.format('%.4f', trace.fuelUsedLiters[index] or 0),
        string.format('%.3f', (trace.ersLevel[index] or 0) * 100),
        string.format('%.6f', trace.ersDeploy[index] or 0),
        string.format('%.6f', trace.ersRecover[index] or 0),
        tostring(trace.mgukDelivery[index] or 0),
        tostring(trace.mgukRecovery[index] or 0),
        string.format('%.3f', trace.worldX[index] or 0),
        string.format('%.3f', trace.worldY[index] or 0),
        string.format('%.3f', trace.worldZ[index] or 0),
        csvText(trace.sector[index] or '')
      }, ',')
    end
  end

  io.createFileDir(filename)
  if io.save(filename, table.concat(rows, '\n')) then
    lastCSVPath, exportStatus, exportStatusTime = filename, 'CSV GUARDADO', 3
    return true
  end
  exportStatus, exportStatusTime = 'ERROR CSV', 4
  return false
end

local function buildSectorMap(trace)
  local sectors, previousName = {}, nil
  for index = 1, BIN_COUNT do
    local name = trace.sector[index]
    if name and #name > 0 and name ~= previousName then
      sectors[#sectors + 1] = {
        index = index - 1,
        position = round((index - 1) / (BIN_COUNT - 1), 6),
        name = name
      }
      previousName = name
    end
  end
  if #sectors <= 1 then
    sectors = {
      {index = 0, position = 0, name = 'Sector 1'},
      {index = math.floor((BIN_COUNT - 1) / 3), position = round(1 / 3, 6), name = 'Sector 2'},
      {index = math.floor((BIN_COUNT - 1) * 2 / 3), position = round(2 / 3, 6), name = 'Sector 3'}
    }
  end
  return sectors
end

local function traceToLap(trace)
  local channels = {
    index = {}, lapTimeMs = {}, throttle = {}, brake = {}, clutch = {},
    steer = {}, steerDeg = {}, speedKmh = {}, gear = {},
    fuelLiters = {}, fuelUsedLiters = {},
    ersLevel = {}, ersDeploy = {}, ersRecover = {},
    mgukDelivery = {}, mgukRecovery = {},
    x = {}, y = {}, z = {}
  }
  for index = 1, BIN_COUNT do
    if trace.throttle[index] ~= nil then
      local outputIndex = #channels.index + 1
      channels.index[outputIndex] = index - 1
      channels.lapTimeMs[outputIndex] = math.floor((trace.timeMs[index] or 0) + 0.5)
      channels.throttle[outputIndex] = round(trace.throttle[index], 4)
      channels.brake[outputIndex] = round(trace.brake[index], 4)
      channels.clutch[outputIndex] = round(trace.clutch[index], 4)
      channels.steer[outputIndex] = round(trace.steer[index], 4)
      channels.steerDeg[outputIndex] = round(trace.steerDeg[index], 2)
      channels.speedKmh[outputIndex] = round(trace.speedKmh[index], 2)
      channels.gear[outputIndex] = trace.gear[index] or 0
      channels.fuelLiters[outputIndex] = round(trace.fuelLiters[index], 4)
      channels.fuelUsedLiters[outputIndex] = round(trace.fuelUsedLiters[index], 4)
      channels.ersLevel[outputIndex] = round(trace.ersLevel[index], 5)
      channels.ersDeploy[outputIndex] = round(trace.ersDeploy[index], 5)
      channels.ersRecover[outputIndex] = round(trace.ersRecover[index], 5)
      channels.mgukDelivery[outputIndex] = trace.mgukDelivery[index] or 0
      channels.mgukRecovery[outputIndex] = trace.mgukRecovery[index] or 0
      channels.x[outputIndex] = round(trace.worldX[index], 2)
      channels.y[outputIndex] = round(trace.worldY[index], 2)
      channels.z[outputIndex] = round(trace.worldZ[index], 2)
    end
  end
  return {
    number = trace.lapNumber,
    timeMs = trace.lapTimeMs,
    valid = trace.valid,
    coverage = round(trace.sampleCount / BIN_COUNT, 4),
    tyreCompound = trace.tyreCompound,
    tyreCompoundLong = trace.tyreCompoundLong,
    fuelAvailable = trace.fuelAvailable,
    fuelStartLiters = round(trace.fuelStartLiters or 0, 4),
    fuelEndLiters = round(trace.fuelEndLiters or 0, 4),
    fuelUsedLiters = round(trace.fuelConsumedLiters or 0, 4),
    hybridAvailable = trace.hybridAvailable,
    ersStartPercent = round(trace.ersStartPercent or 0, 3),
    ersEndPercent = round(trace.ersEndPercent or 0, 3),
    ersDeployedPercent = round(trace.ersDeployedPercent or 0, 3),
    ersRecoveredPercent = round(trace.ersRecoveredPercent or 0, 3),
    channels = channels
  }
end

local function mapFromLap(lap)
  return {index = lap.channels.index, x = lap.channels.x, y = lap.channels.y, z = lap.channels.z}
end

local function shouldBecomeBest(trace)
  if trace.lapTimeMs <= 0 then return false end
  if trace.valid then
    return not sessionData.bestLapValid or sessionData.bestLapTimeMs <= 0 or trace.lapTimeMs < sessionData.bestLapTimeMs
  end
  return not sessionData.bestLapValid and (sessionData.bestLapTimeMs <= 0 or trace.lapTimeMs < sessionData.bestLapTimeMs)
end

local function saveSessionData()
  sessionData.updatedAt = os.date('%Y-%m-%dT%H:%M:%S')
  sessionData.lapCount = #sessionData.laps
  io.createFileDir(sessionFilename)
  if io.save(sessionFilename, JSON.stringify(sessionData)) then
    lastSessionPath, exportStatus, exportStatusTime = sessionFilename, 'TANDA GUARDADA', 3
    return true
  end
  exportStatus, exportStatusTime = 'ERROR TANDA', 4
  return false
end

local function appendTraceToSession(trace)
  local lap = traceToLap(trace)
  sessionData.laps[#sessionData.laps + 1] = lap
  sessionData.capabilities.fuel = sessionData.capabilities.fuel or trace.fuelAvailable
  sessionData.capabilities.tyres = sessionData.capabilities.tyres or #trace.tyreCompound > 0
  sessionData.capabilities.hybrid = sessionData.capabilities.hybrid or trace.hybridAvailable
  if #sessionData.sectors == 0 then sessionData.sectors = buildSectorMap(trace) end

  local becomesBest = shouldBecomeBest(trace)
  if #sessionData.trackMap.index == 0 or becomesBest then sessionData.trackMap = mapFromLap(lap) end
  if becomesBest then
    sessionData.bestLapNumber = trace.lapNumber
    sessionData.bestLapTimeMs = trace.lapTimeMs
    sessionData.bestLapValid = trace.valid
  end
  return saveSessionData()
end

local function finishLap(newLapCount)
  currentTrace.lapNumber = newLapCount
  currentTrace.lapTimeMs = math.max(0, tonumber(car.previousLapTimeMs) or 0)
  local complete = currentTrace.fullLap and currentTrace.sampleCount / BIN_COUNT >= MIN_COMPLETE_COVERAGE
  if complete then
    previousTrace = currentTrace
    if settings.autoExport then exportTraceCSV(previousTrace, false) end
    appendTraceToSession(previousTrace)
  end
  currentTrace = newTrace(true)
end

function script.update(dt)
  if not car then
    car = ac.getCar(0)
    if not car then return end
    sessionData.car.steerLockDeg = round(car.steerLock, 2)
  end
  if exportStatusTime > 0 then exportStatusTime = math.max(0, exportStatusTime - dt) end
  liveSplinePosition = clamp01(car.splinePosition)
  if sim.isReplayActive or sim.isPaused or sim.isInMainMenu or sim.trackLengthM < 1 then return end

  if car.justJumped then
    currentTrace, lastLapCount = newTrace(false), car.lapCount
    return
  end

  local lapCount = tonumber(car.lapCount) or 0
  if lapCount > lastLapCount then
    finishLap(lapCount)
    lastLapCount = lapCount
  elseif lapCount < lastLapCount then
    currentTrace, lastLapCount = newTrace(false), lapCount
  end
  recordSample(currentTrace, liveSplinePosition, dt)
end

local function withAlpha(color, alpha)
  return rgbm(color.r, color.g, color.b, alpha)
end

local function drawChannelLine(values, color, thickness, graphFrom, graphSize, transform)
  if not values then return end
  local step = math.max(1, math.floor(BIN_COUNT / math.max(1, math.floor(graphSize.x))))
  local pointsInPath = 0
  local function finishPath()
    if pointsInPath > 0 then ui.pathStroke(color, false, thickness) end
    pointsInPath = 0
  end

  local index = 1
  while index <= BIN_COUNT do
    local value = values[index]
    if value ~= nil then
      value = transform and transform(value) or value
      local x = (index - 1) / (BIN_COUNT - 1)
      ui.pathLineTo(graphFrom + vec2(x * graphSize.x, (1 - clamp01(value)) * graphSize.y))
      pointsInPath = pointsInPath + 1
    elseif pointsInPath > 0 then finishPath() end
    index = index + step
  end
  if (BIN_COUNT - 1) % step ~= 0 and values[BIN_COUNT] ~= nil then
    local value = transform and transform(values[BIN_COUNT]) or values[BIN_COUNT]
    ui.pathLineTo(graphFrom + vec2(graphSize.x, (1 - clamp01(value)) * graphSize.y))
    pointsInPath = pointsInPath + 1
  end
  if pointsInPath > 0 then finishPath() end
end

local function drawTrace(trace, alpha, thickness, graphFrom, graphSize)
  if not trace then return end
  drawChannelLine(trace.throttle, withAlpha(colors.throttle, alpha), thickness, graphFrom, graphSize)
  drawChannelLine(trace.brake, withAlpha(colors.brake, alpha), thickness, graphFrom, graphSize)
  if settings.showClutch then
    drawChannelLine(trace.clutch, withAlpha(colors.clutch, alpha), thickness, graphFrom, graphSize)
  end
  if settings.showSteer then
    drawChannelLine(trace.steer, withAlpha(colors.steer, alpha), thickness, graphFrom, graphSize, function(value)
      return 0.5 + value * 0.5
    end)
  end
end

local function drawLegend(windowFrom, windowSize)
  ui.pushFont(ui.Font.Small)
  local compact = windowSize.x < 560
  local items = {
    {text = string.format(compact and 'A %.0f' or 'ACEL %.0f', liveThrottle * 100), color = colors.throttle},
    {text = string.format(compact and 'F %.0f' or 'FRENO %.0f', liveBrake * 100), color = colors.brake}
  }
  if settings.showClutch then
    items[#items + 1] = {text = string.format(compact and 'E %.0f' or 'EMB %.0f', liveClutch * 100), color = colors.clutch}
  end
  if settings.showSteer then
    items[#items + 1] = {text = string.format(compact and 'V %.0f' or 'VOL %.0f', liveSteer * 100), color = colors.steer}
  end
  items[#items + 1] = {
    text = liveGear < 0 and 'M R' or liveGear == 0 and 'M N' or string.format('M %d', liveGear),
    color = colors.text
  }
  if windowSize.x >= 620 then
    items[#items + 1] = {text = string.format('FUEL %.1f L', liveFuel), color = colors.fuel}
  end
  if liveHybridAvailable and windowSize.x >= 760 then
    local flow = liveERSDeploy > 0.01 and string.format('ERS -%.0f', liveERSDeploy * 100)
      or liveERSRecover > 0.01 and string.format('ERS +%.0f', liveERSRecover * 100)
      or string.format('ERS %.0f%%', liveERSLevel * 100)
    items[#items + 1] = {text = flow, color = colors.energy}
  end
  if #liveTyreCompound > 0 and windowSize.x >= 900 then
    items[#items + 1] = {text = 'NEUM ' .. liveTyreCompound, color = colors.text}
  end
  local cursor = windowFrom + vec2(9, 4)
  for _, item in ipairs(items) do
    ui.drawText(item.text, cursor, item.color)
    cursor.x = cursor.x + ui.measureText(item.text).x + 14
  end

  local status, statusColor
  if exportStatusTime > 0 then
    status = exportStatus
    statusColor = exportStatus:find('ERROR', 1, true) and colors.brake or colors.throttle
  else
    status = string.format('VTA %d  ·  %.0f%%', (tonumber(car.lapCount) or 0) + 1, liveSplinePosition * 100)
    statusColor = colors.text
  end
  local statusWidth = ui.measureText(status).x
  if cursor.x + statusWidth + 12 < windowFrom.x + windowSize.x then
    ui.drawText(status, windowFrom + vec2(windowSize.x - statusWidth - 9, 4), statusColor)
  end
  ui.popFont()
end

function script.windowMain()
  local windowFrom, windowSize = ui.getCursor(), ui.availableSpace()
  ui.dummy(windowSize)
  if windowSize.x < 20 or windowSize.y < 20 then return end

  if settings.backgroundOpacity > 0.001 then
    ui.drawRectFilled(windowFrom, windowFrom + windowSize,
      withAlpha(colors.background, settings.backgroundOpacity), 7)
  end
  if settings.showHeader then drawLegend(windowFrom, windowSize) end

  local topMargin = settings.showHeader and 25 or 9
  local graphFrom = windowFrom + vec2(9, topMargin)
  local graphSize = windowSize - vec2(18, topMargin + 9)
  if graphSize.x < 20 or graphSize.y < 20 then return end

  if settings.showGrid then
    for division = 0, 4 do
      local x = graphFrom.x + graphSize.x * division / 4
      local y = graphFrom.y + graphSize.y * division / 4
      ui.drawLine(vec2(x, graphFrom.y), vec2(x, graphFrom.y + graphSize.y), colors.grid, 1)
      ui.drawLine(vec2(graphFrom.x, y), vec2(graphFrom.x + graphSize.x, y), colors.grid, 1)
    end
  end

  ui.pushClipRect(graphFrom, graphFrom + graphSize)
  if settings.showPrevious then
    drawTrace(previousTrace, 0.23, math.max(1, settings.lineThickness - 0.4), graphFrom, graphSize)
  end
  drawTrace(currentTrace, 0.96, settings.lineThickness, graphFrom, graphSize)
  if settings.showProgressCursor then
    local progressX = graphFrom.x + liveSplinePosition * graphSize.x
    ui.drawLine(vec2(progressX, graphFrom.y), vec2(progressX, graphFrom.y + graphSize.y), colors.cursor, 1)
  end
  ui.popClipRect()
end

function script.windowSettings()
  if ui.checkbox('Mostrar vuelta anterior', settings.showPrevious) then settings.showPrevious = not settings.showPrevious end
  if ui.checkbox('Mostrar embrague', settings.showClutch) then settings.showClutch = not settings.showClutch end
  if ui.checkbox('Mostrar volante', settings.showSteer) then settings.showSteer = not settings.showSteer end
  if ui.checkbox('Mostrar datos superiores', settings.showHeader) then settings.showHeader = not settings.showHeader end
  if ui.checkbox('Mostrar grilla', settings.showGrid) then settings.showGrid = not settings.showGrid end
  if ui.checkbox('Mostrar cursor de progreso', settings.showProgressCursor) then settings.showProgressCursor = not settings.showProgressCursor end
  if ui.checkbox('Embrague como presión de pedal', settings.clutchAsPedal) then settings.clutchAsPedal = not settings.clutchAsPedal end
  if ui.itemHovered() then ui.setTooltip('Activado: 0% con el pedal suelto y 100% al pisarlo.') end
  if ui.checkbox('Exportar también un CSV por vuelta', settings.autoExport) then settings.autoExport = not settings.autoExport end

  settings.lineThickness = ui.slider('##lineThickness', settings.lineThickness, 1, 4, 'Grosor de líneas: %.1f px')
  settings.backgroundOpacity = ui.slider('##backgroundOpacity', settings.backgroundOpacity * 100,
    0, 95, 'Opacidad de fondo: %.0f%%') / 100

  ui.separator()
  ui.textWrapped('Cada vuelta completa agrega inputs, marcha, combustible, neumático y energía híbrida al archivo de tanda para analizarla después en el HTML.')
  if previousTrace then
    if ui.button('Exportar última vuelta en CSV', vec2(ui.availableSpaceX(), 0)) then exportTraceCSV(previousTrace, true) end
  else
    ui.pushDisabled(); ui.button('Aún no hay una vuelta completa', vec2(ui.availableSpaceX(), 0)); ui.popDisabled()
  end

  if #sessionData.laps > 0 then
    if ui.button('Guardar archivo de tanda ahora', vec2(ui.availableSpaceX(), 0)) then saveSessionData() end
  else
    ui.pushDisabled(); ui.button('La tanda todavía no tiene vueltas', vec2(ui.availableSpaceX(), 0)); ui.popDisabled()
  end

  if ui.button('Abrir carpeta de telemetría', vec2(ui.availableSpaceX(), 0)) then
    io.createDir(exportDirectory); os.openInExplorer(exportDirectory)
  end
  if lastSessionPath then
    ui.textWrapped('Tanda: ' .. lastSessionPath:match('[^/\\]+$'))
  elseif lastCSVPath then
    ui.textWrapped('Último CSV: ' .. lastCSVPath:match('[^/\\]+$'))
  end
  if ui.button('Limpiar trazas en pantalla', vec2(ui.availableSpaceX(), 0)) then
    previousTrace, currentTrace = nil, newTrace(false)
  end
end
